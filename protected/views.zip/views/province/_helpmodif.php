<?php echo Catalogsys::model()->getcatalog('provincehelpmodif'); ?>
