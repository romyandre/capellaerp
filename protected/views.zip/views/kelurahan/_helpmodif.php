<h1>Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Schedule Name
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Schedule, Pilihan dari modul <a href="index.php?r=absschedule/index">Absence Schedule</a>
	</td>
  </tr>
  <tr>
	<td>
	  Time In
	</td>
	<td>
	  Angka, 0-9, Format 00:00
	</td>
	<td>
	  Waktu untuk melakukan absence in
	</td>
  </tr>
  <tr>
	<td>
	  Time Out
	</td>
	<td>
	  Angka, 0-9, Format 00:00
	</td>
	<td>
	  Waktu untuk melakukan absence out
	</td>
  </tr>
  <tr>
	<td>
	  Status
	</td>
	<td>
	  Pilihan, dari modul <a href="index.php?r=absstatus/index">Absence Status</a>
	</td>
	<td>
	  Status yang diberikan ketika tidak melakukan absensi, <br>
biasanya diberikan tanda A (Alpha), L (Libur), * (tanggal dimana tidak ada tanggal di bulan berjalan)<br>
	</td>
  </tr>
</table>

