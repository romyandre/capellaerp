<?php echo Catalogsys::model()->getcatalog('wfgrouphelp'); ?>

