<h1>Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Blood Type Name
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Golongan Darah
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  checkbox
	</td>
	<td>
	  Status aktif (check) / tidak (uncheck)
	</td>
  </tr>
</table>

