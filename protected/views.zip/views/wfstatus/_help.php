<h1>Pendahuluan</h1>
Modul Blood Type digunakan untuk mendaftarkan golongan darah.