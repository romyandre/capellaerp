<div id="help">
<h1 class="h1help">Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Country
	</td>
	<td>
	  Pilihan dari modul <a href="index.php?r=country/index">Country</a>
	</td>
	<td>
	  Nama Negara
	</td>
  </tr>
  <tr>
	<td>
	  Currency Name
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Mata Uang
	</td>
  </tr>
  <tr>
	<td>
	  Symbol
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Symbol Mata Uang
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  Check / Uncheck
	</td>
	<td>
	  Status aktif (check) / tidak aktif (uncheck)
	</td>
  </tr>
</table>
</div>
