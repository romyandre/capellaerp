<div id="help">
<h1 class="h1help">Pendahuluan</h1>
<p class="phelp">Modul Currency digunakan untuk mendaftarkan nama mata uang</p>
<h1 class="h1help">Relasi</h1>
<p class="phelp">Data Currency digunakan di seluruh modul</p>
</div>