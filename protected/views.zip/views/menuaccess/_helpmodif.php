<?php echo Catalogsys::model()->getcatalog('menuaccesshelpmodif'); ?>
