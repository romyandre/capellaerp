<?php echo Catalogsys::model()->getcatalog('menuauthhelpmodif'); ?>

