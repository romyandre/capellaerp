<?php echo Catalogsys::model()->getcatalog('usergrouphelpmodif'); ?>
