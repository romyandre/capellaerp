<div id="help">
<h1 class="h1help">Pendahuluan</h1>
<p class="phelp">Modul Sloc atau Storage Location digunakan untuk mendaftarkan gudang</p>
<h1 class="h1help">Relasi</h1>
<p class="phelp">Data Sloc digunakan di modul : Material Stock Overview, Material Detail,<br/>
Purchase Request, Purchase Order, Form Permintaan (Barang/Jasa/Pengiriman), Goods Received, Goods Issue</p>
</div>