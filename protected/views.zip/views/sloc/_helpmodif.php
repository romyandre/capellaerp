<div id="help">
<h1 class="h1help">Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Plant Name
	</td>
	<td>
	  Pilihan dari modul <a href="index.php?r=plant/index">Plant</a>
	</td>
	<td>
	  Nama Plant
	</td>
  </tr>
  <tr>
	<td>
	  Sloc Code
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Kode Storage Location
	</td>
  </tr>
  <tr>
	<td>
	  Description
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Keterangan Storage Location
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  Check / uncheck
	</td>
	<td>
	  Status aktif (check) / tidak aktif (uncheck)
	</td>
  </tr>
</table>
</div>

