<h1>Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Plant Code
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Plant / Pabrik
	</td>
  </tr>
  <tr>
	<td>
	  Description
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Keterangan Plant
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  Check/Uncheck
	</td>
	<td>
	  Status record, apakah aktif (Check) atau tidak aktif (Uncheck)
	</td>
  </tr>
</table>

