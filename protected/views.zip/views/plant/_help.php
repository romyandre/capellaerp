<h1>Pendahuluan</h1>
Modul Plant digunakan untuk mendaftarkan nama factory / pabrik. <br/>
1 company dimungkinkan memiliki banyak pabrik.