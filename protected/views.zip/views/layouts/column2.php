<?php $this->beginContent('//layouts/empty'); ?>
<div id="contentempty">
	<?php echo $content; ?>
</div><!-- content -->
<?php $this->endContent(); ?>