<?php echo Catalogsys::model()->getcatalog('groupaccesshelpmodif'); ?>
