<div id="help">
<h1 class="h1help">Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Sub District
	</td>
	<td>
	  Pilihan, modul <a href="index.php?r=subdistrict/index"> Subdistrict</a>
	</td>
	<td>
	  Kode Kecamatan
	</td>
  </tr>
  <tr>
	<td>
	  Sub Subdistrict Name
	</td>
	<td>
	  Karakter, A-Z, a-z, 0-9
	</td>
	<td>
	  Nama Kelurahan
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  Check/Uncheck
	</td>
	<td>
	  Status record, apakah aktif (Check) atau tidak aktif (Uncheck)
	</td>
  </tr>
</table>
</div>
