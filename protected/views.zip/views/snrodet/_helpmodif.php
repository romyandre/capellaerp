<?php echo Catalogsys::model()->getcatalog('snrodethelpmodif'); ?>
