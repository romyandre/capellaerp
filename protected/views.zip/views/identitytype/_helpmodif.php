<h1>Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Identity Type Name
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Identitas
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  Check/Uncheck
	</td>
	<td>
	  Status record, apakah aktif (Check) atau tidak aktif (Uncheck)
	</td>
  </tr>
</table>

