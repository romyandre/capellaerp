<h1>Pendahuluan</h1>
Modul ini digunakan untuk mendaftarkan jenis industri.