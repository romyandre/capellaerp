<div id="help">
<h1 class="h1help">Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  UOM Code
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Kode Satuan
	</td>
  </tr>
  <tr>
	<td>
	  Description
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Keterangan
	</td>
  </tr>
  <tr>
	<td>
	  Status
	</td>
	<td>
	  Checkbox
	</td>
	<td>
	  Status aktif (check) / tidak aktif (uncheck)
	</td>
  </tr>
</table>
</div>
