<div id="help">
<h1 class="h1help">Pendahuluan</h1>
<p class="phelp">Modul Unit of Measure digunakan untuk memasukkan data satuan</p>
<h1 class="h1help">Relasi</h1>
<p class="phelp">Data UOM digunakan di modul : Purchase Request, Purchase Order, Form Permintaan (Barang/Jasa/Pengiriman)</p>
</div>