<h1>Pendahuluan</h1>
Modul Contacttype digunakan untuk mendaftarkan jenis contact
