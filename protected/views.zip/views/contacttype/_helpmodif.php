<h1>Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Contact Type Name
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Contact
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  Check / Uncheck
	</td>
	<td>
	  Status aktif (check) / tidak aktif (uncheck)
	</td>
  </tr>
</table>

