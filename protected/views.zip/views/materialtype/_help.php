<div id="help">
<h1 class="h1help">Pendahuluan</h1>
<p class="phelp">Modul Material Type digunakan untuk menentukan jenis material. <br/>
contoh : bahan baku, sparepart, office supply</p>
<h1 class="h1help">Relasi</h1>
<p class="phelp">Data Material Type digunakan di modul : Material Group, Material Master</p>
</div>
