<div id="help">
<h1 class="h1help">Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Material Type Code
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Nama Kode Material
	</td>
  </tr>
  <tr>
	<td>
	  Description
	</td>
	<td>
	  Karakter, A-Z, a-z
	</td>
	<td>
	  Keterangan
	</td>
  </tr>
  <tr>
	<td>
	  Record Status
	</td>
	<td>
	  checkbox
	</td>
	<td>
	  Status aktif (check) / tidak (uncheck)
	</td>
  </tr>
</table>
</div>