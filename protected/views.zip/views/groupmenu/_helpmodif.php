<?php echo Catalogsys::model()->getcatalog('groupmenuhelpmodif'); ?>

