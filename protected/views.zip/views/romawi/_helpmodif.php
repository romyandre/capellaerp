<h1>Keterangan Field</h1>

<table>
  <tr>
	<td>
	  <strong>Nama Field</strong>
	</td>
	<td>
	  <strong>Jenis Field</strong>
	</td>
	<td>
	  <strong>Keterangan</strong>
	</td>
  </tr>
  <tr>
	<td>
	  Calendar Month
	</td>
	<td>
	  Karakter, A-Z, a-z, 0-9
	</td>
	<td>
	  Kalendar Bulan
	</td>
  </tr>
  <tr>
	<td>
	  Rome Month
	</td>
	<td>
	  Karakter, A-Z, a-z, 0-9
	</td>
	<td>
	  Kode Romawi
	</td>
  </tr>
</table>

